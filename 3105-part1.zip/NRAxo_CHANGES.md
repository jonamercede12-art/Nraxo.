# Nraxo changes

1. **HOLOGRAMS / HOLO disabled**
   - Hologram cards remain visible but are disabled.
   - They cannot be activated, restored, unlocked, or tapped.
   - They display `DISABLED • NOT AVAILABLE`.

2. **Expired license bindings released**
   - The Supabase `public.activate_license(p_license_key, p_device_id)` function was updated.
   - Before enforcing the one-license-per-device rule, expired licenses are automatically unlinked (`device_id = NULL`).
   - Therefore, when a license expires, that device can activate a newly created license.
   - The migration SQL is included in `supabase/migrations/`.

The Supabase migration has also been applied to the connected project used by the app.
