import SwiftUI
import UIKit

struct ContentView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator
    @State private var tabNavigation: AppTabNavigationState
    @AppStorage(FeatureVisibility.cleanerStorageKey) private var cleanerEnabled = true

    init() {
#if targetEnvironment(simulator)
        let arguments = ProcessInfo.processInfo.arguments
        let initialTab: Int
        if arguments.contains("--simulate-patch-tab") {
            initialTab = 1
        } else if arguments.contains("--simulate-cleaner-tab") {
            initialTab = 2
        } else {
            initialTab = 0
        }
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: initialTab))
#else
        _tabNavigation = State(initialValue: AppTabNavigationState())
#endif
    }

    var body: some View {
        Group {
            if horizontalSizeClass == .regular {
                regularLayout
            } else {
                compactLayout
            }
        }
        .tint(AppTheme.accent)
        .imageScale(.small)
        .onChange(of: patchDraftCoordinator.request?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.patches.rawValue) }
        }
        .onChange(of: patchDraftCoordinator.importRequest?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.patches.rawValue) }
        }
        .onChange(of: cleanerEnabled) { _ in
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onAppear {
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
    }

    private var compactLayout: some View {
        TabView(selection: tabSelection) {
            ForEach(featureVisibility.visibleSections) { section in
                sectionContent(section)
                    .tabItem {
                        CompactTabLabel(
                            title: language.text(section.titleKey),
                            systemImage: section.systemImage
                        )
                    }
                    .tag(section.rawValue)
            }
        }
    }

    private var regularLayout: some View {
        NavigationSplitView {
            List {
                ForEach(featureVisibility.visibleSections) { section in
                    Button {
                        withAnimation(.easeInOut(duration: 0.18)) {
                            tabNavigation.select(section.rawValue)
                        }
                    } label: {
                        Label(language.text(section.titleKey), systemImage: section.systemImage)
                            .fontWeight(section.rawValue == tabNavigation.selectedTab ? .semibold : .regular)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .listRowBackground(
                        section.rawValue == tabNavigation.selectedTab
                            ? AppTheme.accent.opacity(0.14)
                            : Color.clear
                    )
                    .accessibilityAddTraits(
                        section.rawValue == tabNavigation.selectedTab ? .isSelected : []
                    )
                }
            }
            .navigationTitle("Nraxo")
            .navigationSplitViewColumnWidth(min: 210, ideal: 240, max: 300)
        } detail: {
            sectionContent(selectedVisibleSection)
                .id(selectedVisibleSection.rawValue)
        }
        .navigationSplitViewStyle(.balanced)
    }

    @ViewBuilder
    private func sectionContent(_ section: AppSection) -> some View {
        switch section {
        case .home:
            DashboardView()
        case .patches:
            PatchProjectsView()
        case .cleaner:
            CleanerView()
        }
    }

    private var tabSelection: Binding<Int> {
        Binding(
            get: { tabNavigation.selectedTab },
            set: { tabNavigation.select($0) }
        )
    }


    private var featureVisibility: FeatureVisibility {
        FeatureVisibility(cleanerEnabled: cleanerEnabled)
    }

    private var selectedVisibleSection: AppSection {
        guard let section = AppSection(rawValue: tabNavigation.selectedTab),
              featureVisibility.isVisible(section) else {
            return .home
        }
        return section
    }
}

private struct CompactTabLabel: View {
    let title: String
    let systemImage: String

    @ViewBuilder
    var body: some View {
        if let image = UIImage(
            systemName: systemImage,
            withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .medium)
        )?.withRenderingMode(.alwaysTemplate) {
            Image(uiImage: image)
        } else {
            Image(systemName: systemImage)
                .font(.system(size: 17, weight: .medium))
        }
        Text(title)
    }
}

private extension AppSection {
    var titleKey: String {
        switch self {
        case .home: return "tab.home"
        case .patches: return "tab.patches"
        case .cleaner: return "tab.cleaner"
        }
    }

    var systemImage: String {
        switch self {
        case .home: return "house.fill"
        case .patches: return "shippingbox.fill"
        case .cleaner: return "sparkles"
        }
    }
}

private struct DashboardView: View {
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var licenseManager: LicenseManager
    @EnvironmentObject private var deviceIdentity: DeviceIdentity
    @State private var showLogs = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    heroCard
                    securityCard
                    statusCard
                    licenseCard
                    contactCard
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 18)
            }
            .scrollIndicators(.hidden)
            .background(AppTheme.pageBackground.ignoresSafeArea())
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    Button { showLogs = true } label: {
                        Image(systemName: "terminal.fill")
                            .foregroundStyle(AppTheme.silver)
                    }
                }
            }
            .sheet(isPresented: $showLogs) { LogView() }
        }
        .tint(AppTheme.accent)
    }

    private var heroCard: some View {
        VStack(spacing: 14) {
            AppLogo(size: 88)
                .shadow(color: AppTheme.accent.opacity(0.35), radius: 18)

            Text("NRAXO")
                .font(.system(size: 34, weight: .black, design: .rounded))
                .tracking(4)
                .foregroundStyle(.white)

            Text("PANEL EXTERNAL")
                .font(.system(size: 13, weight: .bold, design: .rounded))
                .tracking(2)
                .foregroundStyle(AppTheme.accent)

            Text("Panel actualizado, 100% seguro y diseñado para una experiencia limpia, estable y visualmente premium.")
                .font(.subheadline)
                .multilineTextAlignment(.center)
                .foregroundStyle(AppTheme.silver)
                .padding(.horizontal, 10)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 28)
        .background(
            LinearGradient(
                colors: [
                    AppTheme.accent.opacity(0.18),
                    AppTheme.cardBackground,
                    Color.black
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ),
            in: RoundedRectangle(cornerRadius: 28, style: .continuous)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .stroke(AppTheme.accent.opacity(0.32), lineWidth: 1)
        )
    }

    private var securityCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 10) {
                Image(systemName: "checkmark.shield.fill")
                    .foregroundStyle(AppTheme.accent)
                Text("Nraxo Panel")
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.white)
            }

            Text("Panel actualizado 100% seguro anti-ban y black-list. El mejor panel external del momento.")
                .foregroundStyle(AppTheme.silver)

            Text("Viene con un nuevo bypass muchísimo mejor para su seguridad. Aquí siempre priorizamos su seguridad en Nraxo Panel.")
                .foregroundStyle(AppTheme.silver)

            Divider().overlay(AppTheme.accent.opacity(0.18))

            Text("Soporte")
                .font(.caption.weight(.bold))
                .foregroundStyle(AppTheme.accent)
            Text("Recuerda: si tienes alguna consulta, escríbeme por WhatsApp o Telegram al +1 809 768 1435.")
                .font(.subheadline)
                .foregroundStyle(AppTheme.silver)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(20)
        .background(
            LinearGradient(
                colors: [AppTheme.cardBackground, AppTheme.accent.opacity(0.06)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ),
            in: RoundedRectangle(cornerRadius: 22, style: .continuous)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(AppTheme.accent.opacity(0.22), lineWidth: 1)
        )
    }

    private var statusCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Label("Estado del dispositivo", systemImage: "iphone.gen3")
                    .font(.headline)
                    .foregroundStyle(.white)
                Spacer()
                Text(appState.isSupported ? "SUPPORTED" : "UNSUPPORTED")
                    .font(.caption2.weight(.black))
                    .foregroundStyle(appState.isSupported ? Color.green : AppTheme.accent)
                    .padding(.horizontal, 9)
                    .padding(.vertical, 6)
                    .background(
                        (appState.isSupported ? Color.green : AppTheme.accent).opacity(0.14),
                        in: Capsule()
                    )
            }

            Divider().overlay(AppTheme.silver.opacity(0.18))

            infoRow("Modelo", AppInfo.displayMachineName)
            infoRow("iOS", "\(AppInfo.osVersion) (\(AppInfo.osBuild))")
        }
        .padding(20)
        .background(AppTheme.cardBackground, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(AppTheme.silver.opacity(0.12), lineWidth: 1)
        )
    }

    private func infoRow(_ title: String, _ value: String) -> some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title)
                .foregroundStyle(AppTheme.silver)
            Spacer()
            Text(value)
                .font(.subheadline.monospaced())
                .foregroundStyle(.white)
                .multilineTextAlignment(.trailing)
        }
    }

    private var licenseCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("Licencia", systemImage: "key.fill")
                    .font(.headline)
                    .foregroundStyle(.white)
                Spacer()
                Text(licenseManager.isAuthorized ? "ACTIVA" : "INACTIVA")
                    .font(.caption2.weight(.black))
                    .foregroundStyle(licenseManager.isAuthorized ? Color.green : AppTheme.accent)
                    .padding(.horizontal, 9)
                    .padding(.vertical, 6)
                    .background(
                        (licenseManager.isAuthorized ? Color.green : AppTheme.accent).opacity(0.14),
                        in: Capsule()
                    )
            }

            Divider().overlay(AppTheme.silver.opacity(0.18))

            infoRow("Llave", licenseManager.maskedKey)
            infoRow("Tiempo restante", remainingLicenseText)
            infoRow("Device ID", deviceIdentity.deviceID ?? "No disponible")
        }
        .padding(20)
        .background(AppTheme.cardBackground, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(AppTheme.silver.opacity(0.12), lineWidth: 1)
        )
    }

    private var remainingLicenseText: String {
        guard let remaining = licenseManager.remainingInterval else { return "Sin vencimiento informado" }
        if remaining <= 0 { return "Vencida" }
        let totalMinutes = Int(remaining / 60)
        let days = totalMinutes / (60 * 24)
        let hours = (totalMinutes % (60 * 24)) / 60
        let minutes = totalMinutes % 60
        if days > 0 { return "\(days)d \(hours)h \(minutes)m" }
        if hours > 0 { return "\(hours)h \(minutes)m" }
        return "\(minutes)m"
    }

    private var contactCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Nraxo")
                .font(.title3.weight(.bold))
                .foregroundStyle(.white)

            Text("¿Tienes alguna consulta? Escríbenos por WhatsApp o Telegram.")
                .foregroundStyle(AppTheme.silver)

            HStack(spacing: 10) {
                Image(systemName: "message.fill")
                Text("+1 809 768 1435")
                    .font(.headline.monospaced())
            }
            .foregroundStyle(AppTheme.accent)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(20)
        .background(
            LinearGradient(
                colors: [AppTheme.cardBackground, AppTheme.accent.opacity(0.08)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ),
            in: RoundedRectangle(cornerRadius: 22, style: .continuous)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(AppTheme.accent.opacity(0.22), lineWidth: 1)
        )
    }
}

