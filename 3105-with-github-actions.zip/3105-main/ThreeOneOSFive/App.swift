import SwiftUI
import UIKit
import Foundation
import Security

@main
struct ThreeOneOSFiveApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var patchDraftCoordinator = PatchDraftCoordinator()
    @StateObject private var fileOperationCoordinator = FileOperationCoordinator()
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @State private var showOnboarding = OnboardingStore.shouldShow()
    @State private var showAttribution = false
    @State private var showWelcome = false
    @State private var welcomeShown = false
    @State private var updateOffer: AppUpdateChecker.Offer?
    @Environment(\.scenePhase) private var scenePhase

    init() {
        setupLogCapture()
        log("app: 3105 launching — iOS \(AppInfo.osVersion) (\(AppInfo.osBuild)) \(AppInfo.machineName)")
    }

    private var language: AppLanguage {
        AppLanguage(rawValue: languageCode) ?? .english
    }

    private func presentWelcome() {
        guard !welcomeShown else { return }
        welcomeShown = true
        showWelcome = true
        Task {
            try? await Task.sleep(nanoseconds: 5_000_000_000)
            await MainActor.run {
                withAnimation(.easeOut(duration: 0.35)) {
                    showWelcome = false
                }
            }
        }
    }

    private func checkForUpdate() {
        Task {
            guard let offer = await AppUpdateChecker.check() else { return }
            await MainActor.run { updateOffer = offer }
        }
    }

    var body: some Scene {
        WindowGroup {
            LicenseGateView {
                ZStack {
                ContentView()
                    .environmentObject(appState)
                    .environmentObject(patchDraftCoordinator)
                    .environmentObject(fileOperationCoordinator)
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .opacity(showOnboarding ? 0 : 1)
                    .allowsHitTesting(!showOnboarding)

                if showOnboarding {
                    OnboardingView {
                        OnboardingStore.markCompleted()
                        withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) {
                            showOnboarding = false
                        }
                        presentWelcome()
                        appState.detectSupport()
                        checkForUpdate()
                    }
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .transition(.opacity.combined(with: .scale(scale: 0.98)))
                    .zIndex(1)
                }
                }
                .displayIdentityAttribution(isPresented: $showAttribution, enabled: !showOnboarding)
            .sheet(isPresented: $showAttribution) {
                DisplayAttributionSheet()
            }
            .alert(item: $updateOffer) { offer in
                Alert(
                    title: Text(language.text("update.title")),
                    message: Text(language.text("update.message", offer.version)),
                    primaryButton: .default(Text(language.text("update.agree"))) {
                        UIApplication.shared.open(offer.url)
                    },
                    secondaryButton: .cancel(Text(language.text("update.dismiss"))) {
                        AppUpdateChecker.dismiss(version: offer.version)
                    }
                )
            }
            .onAppear {
                if !showOnboarding {
                    appState.detectSupport()
                    checkForUpdate()
                    presentWelcome()
                }
            }
            .onChange(of: scenePhase) { phase in
                guard phase == .active, !showOnboarding else { return }
                appState.detectSupport()
            }
                .onOpenURL { url in
                    patchDraftCoordinator.presentImport(url)
                }
            }
        }
    }
}

private struct WelcomeView: View {
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 22) {
                AppLogo(size: 112)
                    .shadow(color: AppTheme.accent.opacity(0.45), radius: 28)

                Text("BIENVENIDO")
                    .font(.system(size: 32, weight: .black, design: .rounded))
                    .tracking(3)
                    .foregroundStyle(.white)

                Text("Al mejor panel del momento")
                    .font(.headline)
                    .foregroundStyle(AppTheme.silver)

                Text("Nraxo Panel External")
                    .font(.title2.weight(.bold))
                    .foregroundStyle(AppTheme.accent)
            }
            .padding(32)
            .frame(maxWidth: 420)
        }
    }
}

class AppState: ObservableObject {
    @Published var exploitStatus: ExploitStatus = .notStarted
    @Published var unsupportedMessage: String?
    @Published var kernelExploitRunning = false

    private var autoRunAttempted = false

    var kernelExploitApplicable: Bool {
        KernelExploit.isApplicable(
            major: AppInfo.versionTuple.major,
            minor: AppInfo.versionTuple.minor,
            patch: AppInfo.versionTuple.patch,
            build: AppInfo.osBuild
        )
    }

    var isSupported: Bool { unsupportedMessage == nil }

    func detectSupport() {
        let v = AppInfo.versionTuple
        let supported = ExploitSupportPolicy.isSupported(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
#if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--simulate-access") {
            exploitStatus = .success(method: "Simulator preview")
        }
#endif

        unsupportedMessage = supported ? nil : "iOS \(AppInfo.osVersion) (\(AppInfo.osBuild))"
        if let unsupportedMessage {
            exploitStatus = .unsupported(unsupportedMessage)
            return
        }

        let applicable = KernelExploit.isApplicable(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
        guard applicable else { return }

        refreshKernelExploitStatus()
        maybeAutoRunKernelExploit()
    }

    private func maybeAutoRunKernelExploit() {
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed,
              !autoRunAttempted else { return }
        autoRunAttempted = true
        log("app: starting kernel exploit automatically")
        runKernelExploitIfNeeded()
    }

    private func refreshKernelExploitStatus() {
        guard !kernelExploitRunning else { return }

        // iOS < 26: kernel R/W success persists (no sandbox probe)
        // iOS >= 26: verify full sandbox escape is still active
        if KernelExploit.requiresSandboxEscape {
            if KernelExploit.hasSandboxAccess() {
                if !exploitStatus.isSuccess {
                    exploitStatus = .success(method: "kexploit")
                    log("app: existing sandbox access is still active; skipping kernel exploit")
                }
            } else if exploitStatus.isSuccess {
                exploitStatus = .notStarted
                log("app: sandbox access is no longer active")
            }
        }
    }

    func runKernelExploitIfNeeded() {
        refreshKernelExploitStatus()
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed else { return }
        kernelExploitRunning = true
        exploitStatus = .notStarted
        log("app: running kernel exploit on background...")
        DispatchQueue.global(qos: .userInitiated).async {
            let ok = KernelExploit.run()
            DispatchQueue.main.async {
                self.kernelExploitRunning = false
                if ok {
                    self.exploitStatus = .success(method: "kexploit")
                    if KernelExploit.requiresSandboxEscape {
                        log("app: kernel exploit success — sandbox access verified")
                    } else {
                        log("app: kernel exploit success — kernel access active")
                    }
                } else {
                    self.exploitStatus = .failed(method: "kexploit", code: -1)
                    log("app: kernel exploit failed — relaunch the app before retrying")
                }
            }
        }
    }
}

// MARK: - License gate

/// Uses Apple's public identifierForVendor as the app's Device ID.
/// The user never enters or generates this value. It is registered automatically.
@MainActor
final class DeviceIdentity: ObservableObject {
    @Published private(set) var deviceID: String?
    @Published private(set) var registrationError: String?

    init() {
        deviceID = UIDevice.current.identifierForVendor?.uuidString.uppercased()
        if deviceID == nil {
            registrationError = "No se pudo obtener el Device ID de este dispositivo."
        }
    }
}

@MainActor
final class LicenseManager: ObservableObject {
    @Published private(set) var isChecking = true
    @Published private(set) var isAuthorized = false
    @Published var message: String?
    @Published private(set) var expiresAt: Date?
    @Published private(set) var activatedAt: Date?
    @Published private(set) var linkedAt: Date?

    private let keychainService = "com.threeoneosfive.license"
    private let keychainAccount = "license-key"
    private let keychainExpiryAccount = "license-expiry"
    private let supabaseBaseURL = URL(string: "https://ylupkwemjlzbxhvyfdpl.supabase.co")!
    private let supabaseAnonKey = "sb_publishable_AAyIq1gxTbwFkqgpdbSDnA_D7GaMggG"

    private var deviceID: String? {
        UIDevice.current.identifierForVendor?.uuidString.uppercased()
    }

    func start() {
        Task { await registerAndCheck() }
    }

    func validate(_ key: String) {
        let normalized = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalized.isEmpty else {
            message = "Introduce una llave."
            return
        }
        Task { await activate(normalized) }
    }

    func clearSavedKey() {
        deleteKeychainValue()
        deleteKeychainExpiry()
        isAuthorized = false
        expiresAt = nil
        activatedAt = nil
        linkedAt = nil
        message = nil
        isChecking = false
    }

    var savedKey: String? {
        readKeychainValue()
    }

    var maskedKey: String {
        guard let key = savedKey, !key.isEmpty else { return "—" }
        if key.count <= 8 { return String(repeating: "•", count: key.count) }
        let prefix = key.prefix(4)
        let suffix = key.suffix(4)
        return "\(prefix)••••••••\(suffix)"
    }

    var remainingInterval: TimeInterval? {
        guard let expiresAt else { return nil }
        return max(0, expiresAt.timeIntervalSinceNow)
    }

    private func registerAndCheck() async {
        isChecking = true
        message = nil

        guard let deviceID else {
            isAuthorized = false
            isChecking = false
            message = "No se pudo detectar el Device ID de este dispositivo."
            return
        }

        // If this device already has a saved, non-expired license, restore the
        // session locally. This prevents asking for the key again after the app
        // is closed/reopened. The key is kept in the iOS Keychain.
        if let storedKey = readKeychainValue(),
           let storedExpiry = readKeychainExpiry(),
           storedExpiry > Date() {
            isAuthorized = true
            expiresAt = storedExpiry
            isChecking = false
            return
        }

        // No valid cached session: register the device and validate the key.
        do {
            _ = try await rpc("register_device", body: ["p_device_id": deviceID], response: [DeviceRegistrationResponse].self)

            if let storedKey = readKeychainValue() {
                await activate(storedKey, saveOnSuccess: false)
            } else {
                isAuthorized = false
                isChecking = false
            }
        } catch {
            isAuthorized = false
            isChecking = false
            message = "No se pudo registrar el dispositivo. Comprueba tu conexión a Internet."
        }
    }

    private func activate(_ key: String, saveOnSuccess: Bool = true) async {
        isChecking = true
        message = nil
        defer { isChecking = false }

        guard let deviceID else {
            isAuthorized = false
            message = "No se pudo detectar el Device ID de este dispositivo."
            return
        }

        do {
            let rows = try await rpc(
                "activate_license",
                body: ["p_license_key": key, "p_device_id": deviceID],
                response: [LicenseResponse].self
            )
            guard let result = rows.first else { throw LicenseError.invalidResponse }

            isAuthorized = result.valid
            expiresAt = result.expires_at
            activatedAt = result.activated_at
            linkedAt = result.linked_at

            if result.valid {
                if saveOnSuccess || readKeychainValue() != nil {
                    saveKeychainValue(key)
                    if let expiry = result.expires_at {
                        saveKeychainExpiry(expiry)
                    } else {
                        deleteKeychainExpiry()
                    }
                }
                message = nil
            } else {
                deleteKeychainValue()
                deleteKeychainExpiry()
                message = result.message ?? "Llave inválida."
            }
        } catch let error as LicenseError {
            isAuthorized = false
            message = error.message
        } catch {
            isAuthorized = false
            message = "No se pudo comprobar la licencia. Comprueba tu conexión a Internet."
        }
    }

    private func rpc<T: Decodable>(_ function: String, body: [String: String], response: T.Type) async throws -> T {
        let url = supabaseBaseURL.appendingPathComponent("rest/v1/rpc/\(function)")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(supabaseAnonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(supabaseAnonKey)", forHTTPHeaderField: "Authorization")
        request.timeoutInterval = 15
        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw LicenseError.invalidResponse }
        guard (200...299).contains(http.statusCode) else { throw LicenseError.serverStatus(http.statusCode) }

        do {
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            return try decoder.decode(T.self, from: data)
        } catch {
            throw LicenseError.invalidResponse
        }
    }

    private func saveKeychainValue(_ value: String) {
        let data = Data(value.utf8)
        deleteKeychainValue()
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: keychainAccount,
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        SecItemAdd(query as CFDictionary, nil)
    }

    private func saveKeychainExpiry(_ value: Date) {
        let data = Data(value.ISO8601Format().utf8)
        deleteKeychainExpiry()
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: keychainExpiryAccount,
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        SecItemAdd(query as CFDictionary, nil)
    }

    private func readKeychainExpiry() -> Date? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: keychainExpiryAccount,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data,
              let string = String(data: data, encoding: .utf8) else { return nil }
        return ISO8601DateFormatter().date(from: string)
    }

    private func deleteKeychainExpiry() {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: keychainExpiryAccount
        ]
        SecItemDelete(query as CFDictionary)
    }

    private func readKeychainValue() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: keychainAccount,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func deleteKeychainValue() {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: keychainAccount
        ]
        SecItemDelete(query as CFDictionary)
    }
}

private struct DeviceRegistrationResponse: Decodable {
    let ok: Bool
    let authorized: Bool
    let device_id: String
}

private struct LicenseResponse: Decodable {
    let valid: Bool
    let status: String
    let message: String?
    let license_id: Int64?
    let expires_at: Date?
    let activated_at: Date?
    let linked_at: Date?
}

private enum LicenseError: Error {
    case invalidResponse
    case serverStatus(Int)

    var message: String {
        switch self {
        case .invalidResponse: return "El servidor devolvió una respuesta inválida."
        case .serverStatus(let code): return "El servidor no está disponible (\(code))."
        }
    }
}

struct LicenseGateView<Content: View>: View {
    @StateObject private var licenseManager = LicenseManager()
    @StateObject private var deviceIdentity = DeviceIdentity()
    @State private var key = ""
    private let content: () -> Content

    init(@ViewBuilder content: @escaping () -> Content) {
        self.content = content
    }

    var body: some View {
        Group {
            if licenseManager.isAuthorized {
                content()
                    .environmentObject(licenseManager)
                    .environmentObject(deviceIdentity)
            } else {
                licenseEntryView
            }
        }
        .onAppear { licenseManager.start() }
    }

    private var licenseEntryView: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 22) {
                Spacer()
                Image(systemName: "lock.shield.fill")
                    .font(.system(size: 58))
                    .foregroundStyle(.red)

                Text("Introduce tu llave")
                    .font(.system(size: 30, weight: .bold))
                    .foregroundStyle(.white)

                Text("Tu dispositivo se registra automáticamente.")
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.65))
                    .multilineTextAlignment(.center)

                if let deviceID = deviceIdentity.deviceID {
                    Text("Device ID registrado automáticamente")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.45))
                    Text(deviceID)
                        .font(.caption.monospaced())
                        .foregroundStyle(.white.opacity(0.30))
                        .textSelection(.enabled)
                }

                TextField("Llave de acceso", text: $key)
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled(true)
                    .textFieldStyle(.plain)
                    .padding(.horizontal, 16)
                    .frame(height: 52)
                    .background(Color.white.opacity(0.08))
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .foregroundStyle(.white)
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.white.opacity(0.12), lineWidth: 1))

                Button {
                    licenseManager.validate(key)
                } label: {
                    HStack {
                        if licenseManager.isChecking { ProgressView().tint(.white) }
                        Text(licenseManager.isChecking ? "Comprobando..." : "Validar llave")
                            .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 52)
                }
                .buttonStyle(.borderedProminent)
                .tint(.red)
                .disabled(licenseManager.isChecking || key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

                if let message = licenseManager.message {
                    Text(message)
                        .font(.footnote)
                        .foregroundStyle(.red.opacity(0.9))
                        .multilineTextAlignment(.center)
                }
                Spacer()
            }
            .padding(.horizontal, 28)
            .frame(maxWidth: 520)
        }
        .onSubmit { licenseManager.validate(key) }
    }
}
