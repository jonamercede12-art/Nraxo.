import Foundation

struct PatchLibraryItem: Identifiable {
    let summary: PatchPackageSummary
    var project: PatchProject?
    var contentKey: Data?
    var packageURL: URL

    var id: UUID { summary.packageID }
    var isLocked: Bool { project == nil }
    var workspaceURL: URL? {
        PatchWorkspaceService.workspaceURL(projectID: id)
    }
}

struct PatchPasswordRequest: Identifiable {
    let summary: PatchPackageSummary
    var id: UUID { summary.packageID }
}

enum PatchProjectLibrary {
    private static let bundledRefreshNames: Set<String> = [
        "BODY HS 90- FFTH.3105",
        "DRAG - ANTENA FFTH.3105",
        "TOP HEAD FFTH.3105",
        "HOLOGRAMA WEAPONS FFTH.3105",
        "HOLOGRAMA WEAPONS FFMX.3105"
    ]

    private static let removedLegacyHologramNames: Set<String> = [
        "HOLO FFTH.3105",
        "HOLO AVATAR GREEN.3105",
        "HOLOGRAMA WEAPONS BLUE FFMX.3105",
        "HOLOGRAMA GLOO FFTH.3105"
    ]

    /// Installs the bundled patch package into the local PatchProjects library
    /// the first time the app is launched (or after the local copy is removed).
    /// The original package is shipped as a resource, not as a ZIP.
    static func installBundledDefaults(
        bundle: Bundle = .main,
        fileManager: FileManager = .default
    ) {
        // Every .3105 file bundled in SeedPatches is copied into the local
        // PatchProjects library once. This keeps the patch screen populated
        // with the shipped patch catalog without requiring manual imports.
        let bundledURLs = (
            bundle.urls(forResourcesWithExtension: "3105", subdirectory: "SeedPatches") ?? []
        ) + (bundle.urls(forResourcesWithExtension: "3105", subdirectory: nil) ?? [])


        var seen = Set<String>()
        let sources = bundledURLs.filter { url in
            let name = url.lastPathComponent.uppercased()
            return !name.contains("MAGIC BULLET") &&
                !removedLegacyHologramNames.contains(name) &&
                seen.insert(url.lastPathComponent.lowercased()).inserted
        }

        guard !sources.isEmpty else {
            log("patch: no bundled .3105 packages found")
            return
        }

        do {
            let root = try packageRootURL(fileManager: fileManager)

            for legacyName in removedLegacyHologramNames {
                let legacyURL = root.appendingPathComponent(legacyName)
                if fileManager.fileExists(atPath: legacyURL.path) {
                    try? fileManager.removeItem(at: legacyURL)
                    log("patch: removed legacy hologram \(legacyName)")
                }
            }

            for sourceURL in sources.sorted(by: { $0.lastPathComponent < $1.lastPathComponent }) {
                let destination = root.appendingPathComponent(sourceURL.lastPathComponent)

                // Remove the legacy hologram catalog and refresh the five packages
                // supplied by the current bundle. Other installed packages are preserved.
                if fileManager.fileExists(atPath: destination.path),
                   bundledRefreshNames.contains(sourceURL.lastPathComponent.uppercased()) {
                    try? fileManager.removeItem(at: destination)
                }
                if fileManager.fileExists(atPath: destination.path) {
                    continue
                }

                do {
                    let data = try Data(contentsOf: sourceURL, options: .mappedIfSafe)
                    _ = try PatchPackageCodec.inspect(data)
                    try fileManager.copyItem(at: sourceURL, to: destination)
                    log("patch: installed bundled package \(sourceURL.lastPathComponent)")
                } catch {
                    log("patch: skipped invalid bundled package \(sourceURL.lastPathComponent)")
                }
            }
        } catch {
            log("patch: failed to install bundled patch catalog: \(error)")
        }
    }

    static func packageRootURL(fileManager: FileManager = .default) throws -> URL {
        let base = try fileManager.url(
            for: .applicationSupportDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )
        let root = base.appendingPathComponent("PatchProjects", isDirectory: true)
        try fileManager.createDirectory(at: root, withIntermediateDirectories: true)
        return root
    }

    static func backupRootURL(fileManager: FileManager = .default) throws -> URL {
        let root = try packageRootURL(fileManager: fileManager)
            .appendingPathComponent("Backups", isDirectory: true)
        try fileManager.createDirectory(at: root, withIntermediateDirectories: true)
        return root
    }

    static func load(fileManager: FileManager = .default) -> [PatchLibraryItem] {
        guard let root = try? packageRootURL(fileManager: fileManager),
              let urls = try? fileManager.contentsOfDirectory(
                at: root,
                includingPropertiesForKeys: [.contentModificationDateKey, .fileSizeKey],
                options: [.skipsHiddenFiles, .skipsSubdirectoryDescendants]
              ) else { return [] }

        var byID: [UUID: PatchLibraryItem] = [:]

        for url in urls where
            url.pathExtension.lowercased() == "3105" &&
            !url.lastPathComponent.uppercased().contains("MAGIC BULLET") &&
            !removedLegacyHologramNames.contains(url.lastPathComponent.uppercased()) {
            do {
                let data = try readPackage(at: url)
                let summary = try PatchPackageCodec.inspect(data)
                let decoded: DecodedPatchPackage?
                if let contentKey = try PatchKeyStore.load(for: summary) {
                    decoded = try PatchPackageCodec.decode(data, contentKey: contentKey)
                } else if summary.isPasswordProtected {
                    decoded = nil
                } else {
                    decoded = try PatchPackageCodec.decode(data, password: nil)
                }
                let item = PatchLibraryItem(
                    summary: summary,
                    project: decoded?.project,
                    contentKey: decoded?.contentKey,
                    packageURL: url
                )
                if summary.schemaVersion >= 2, let project = decoded?.project {
                    do {
                        _ = try PatchWorkspaceService.ensureWorkspace(for: project)
                    } catch {
                        log("patch: workspace unavailable for \(project.id.uuidString)")
                    }
                }
                byID[summary.packageID] = item
            } catch {
                log("patch: skipped invalid local package \(url.lastPathComponent)")
            }
        }
        return byID.values.sorted {
            ($0.project?.updatedAt ?? .distantPast) > ($1.project?.updatedAt ?? .distantPast)
        }
    }

    static func readPackage(at url: URL) throws -> Data {
        let values = try url.resourceValues(forKeys: [.isDirectoryKey, .isRegularFileKey, .isSymbolicLinkKey])
        guard values.isDirectory != true,
              values.isSymbolicLink != true,
              values.isRegularFile == true else {
            throw PatchPackageError.invalidProject
        }
        return try Data(contentsOf: url, options: .mappedIfSafe)
    }

    static func save(
        data: Data,
        projectName: String,
        existingURL: URL? = nil,
        fileManager: FileManager = .default
    ) throws -> URL {
        let destination: URL
        if let existingURL {
            destination = existingURL
        } else {
            let root = try packageRootURL(fileManager: fileManager)
            let baseName = sanitizedFilename(projectName)
            var candidate = root.appendingPathComponent(baseName).appendingPathExtension("3105")
            var suffix = 2
            while fileManager.fileExists(atPath: candidate.path) {
                candidate = root.appendingPathComponent("\(baseName)-\(suffix)").appendingPathExtension("3105")
                suffix += 1
            }
            destination = candidate
        }
        try data.write(to: destination, options: [.atomic, .completeFileProtection])
        return destination
    }

    static func installImportedPackage(
        data: Data,
        decoded: DecodedPatchPackage,
        summary: PatchPackageSummary,
        existingURL: URL?,
        fileManager: FileManager = .default
    ) throws {
        let previousData = try existingURL.map { try readPackage(at: $0) }
        var savedURL: URL?
        do {
            savedURL = try save(
                data: data,
                projectName: decoded.project.name,
                existingURL: existingURL,
                fileManager: fileManager
            )
            if summary.schemaVersion >= 2 {
                _ = try PatchWorkspaceService.replaceWorkspace(
                    with: decoded.project,
                    fileManager: fileManager
                )
            } else {
                try? PatchWorkspaceService.deleteWorkspace(
                    projectID: decoded.project.id,
                    fileManager: fileManager
                )
            }
        } catch {
            if let previousData, let existingURL {
                try? previousData.write(
                    to: existingURL,
                    options: [.atomic, .completeFileProtection]
                )
            } else if let savedURL, fileManager.fileExists(atPath: savedURL.path) {
                try? fileManager.removeItem(at: savedURL)
            }
            throw error
        }
    }

    static func delete(_ item: PatchLibraryItem, fileManager: FileManager = .default) throws {
        if fileManager.fileExists(atPath: item.packageURL.path) {
            try fileManager.removeItem(at: item.packageURL)
        }
        try? PatchWorkspaceService.deleteWorkspace(projectID: item.id, fileManager: fileManager)
        try? PatchKeyStore.delete(for: item.summary)
    }

    static func synchronizeWorkspace(
        item: PatchLibraryItem,
        fileManager: FileManager = .default
    ) throws -> PatchProject {
        guard item.summary.schemaVersion >= 2,
              let baseProject = item.project,
              let contentKey = item.contentKey else {
            throw PatchPackageError.invalidProject
        }
        let workspace = try PatchWorkspaceService.ensureWorkspace(
            for: baseProject,
            fileManager: fileManager
        )
        let project = try PatchWorkspaceService.snapshot(
            baseProject: baseProject,
            workspaceURL: workspace,
            fileManager: fileManager
        )
        let original = try readPackage(at: item.packageURL)
        let updated = try PatchPackageCodec.update(
            original,
            project: project,
            contentKey: contentKey,
            schemaVersion: PatchPackageCodec.latestSchemaVersion
        )
        _ = try save(
            data: updated,
            projectName: project.name,
            existingURL: item.packageURL,
            fileManager: fileManager
        )
        return project
    }

    private static func sanitizedFilename(_ rawName: String) -> String {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-_ "))
        let scalars = rawName.unicodeScalars.map { allowed.contains($0) ? Character(String($0)) : "-" }
        let result = String(scalars)
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .prefix(80)
        return result.isEmpty ? "Patch" : String(result)
    }
}
