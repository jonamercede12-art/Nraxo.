import SwiftUI
import UIKit
struct PatchProjectsView: View {
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var draftCoordinator: PatchDraftCoordinator
    @StateObject private var store = PatchProjectStore()
    @State private var applyingID: UUID?
    @State private var activeIDs: Set<UUID> = []
    @State private var selectedPatchMode: PatchMode = .ffth

    private enum PatchMode: String, CaseIterable, Identifiable {
        case ffth = "FFTH"
        case ffmx = "FFMX"

        var id: String { rawValue }
    }

    private enum PatchCategory: String, CaseIterable, Identifiable {
        case aimbot = "AIMBOT"
        case holograms = "HOLOGRAMS / HOLO"
        case textures = "TEXTURES"

        var id: String { rawValue }

        var icon: String {
            switch self {
            case .aimbot: return "scope"
            case .holograms: return "wand.and.stars"
            case .textures: return "photo.artframe"
            }
        }
    }

    private var modeItems: [PatchLibraryItem] {
        store.items.filter { patchMode(for: $0) == selectedPatchMode }
    }

    private var filteredItems: [PatchLibraryItem] {
        modeItems
    }

    var body: some View {
        NavigationStack {
            ZStack {
                AppTheme.pageBackground
                    .ignoresSafeArea()

                VStack(spacing: 0) {
                    patchModeTabs

                    ScrollView {
                        VStack(alignment: .leading, spacing: 14) {
                            patchSectionHeader

                            if store.items.isEmpty && !store.isBusy {
                                emptyState
                            } else if filteredItems.isEmpty && !store.isBusy {
                                modeEmptyState
                            } else {
                                LazyVStack(alignment: .leading, spacing: 18) {
                                    ForEach(PatchCategory.allCases) { category in
                                        let items = filteredItems
                                            .filter { patchCategory(for: $0) == category }
                                            .sorted { patchSortKey($0) < patchSortKey($1) }

                                        if !items.isEmpty {
                                            VStack(alignment: .leading, spacing: 10) {
                                                Label(category.rawValue, systemImage: category.icon)
                                                    .font(.system(size: 15, weight: .black, design: .rounded))
                                                    .tracking(0.8)
                                                    .foregroundStyle(AppTheme.accent)
                                                    .padding(.horizontal, 4)

                                                LazyVGrid(
                                                    columns: [
                                                        GridItem(.flexible(), spacing: 12),
                                                        GridItem(.flexible(), spacing: 12)
                                                    ],
                                                    spacing: 12
                                                ) {
                                                    ForEach(items) { item in
                                                        patchCard(item)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.top, 12)
                        .padding(.bottom, 28)
                    }
                    .scrollIndicators(.hidden)
                }
            }
            .navigationTitle("Patches")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    Button {
                        restoreAll()
                    } label: {
                        Image(systemName: "arrow.uturn.backward.circle")
                            .font(.system(size: 17, weight: .semibold))
                            .foregroundStyle(activeIDs.isEmpty ? AppTheme.silver : .red)
                    }
                    .disabled(store.isBusy || applyingID != nil || activeIDs.isEmpty)
                    .accessibilityLabel("Restore Originals")

                }
            }
            .sheet(item: $draftCoordinator.request) { request in
                PatchProjectEditorView(
                    existingProject: nil,
                    passwordIsProtected: false,
                    initialDraft: request.draft
                ) { project, password in
                    store.create(project: project, password: password)
                    draftCoordinator.clear()
                }
            }
            .sheet(item: $store.passwordRequest, onDismiss: store.cancelUnlock) { _ in
                PatchUnlockView(store: store)
            }
            .alert(item: $store.alert) { alert in
                Alert(
                    title: Text(language.text(alert.titleKey)),
                    message: Text(alert.message(language: language)),
                    dismissButton: .default(Text(language.text("common.ok")))
                )
            }
            .onAppear {
                syncActiveState()
                consumeExternalImport()
            }
            .onChange(of: draftCoordinator.importRequest?.id) { _ in
                consumeExternalImport()
            }
        }
    }

    private var patchModeTabs: some View {
        HStack(spacing: 0) {
            ForEach(PatchMode.allCases) { mode in
                Button {
                    withAnimation(.easeInOut(duration: 0.18)) {
                        selectedPatchMode = mode
                    }
                } label: {
                    HStack(spacing: 7) {
                        Image(systemName: mode == .ffth ? "antenna.radiowaves.left.and.right" : "bolt.horizontal.fill")
                            .font(.system(size: 13, weight: .bold))
                        Text(mode.rawValue)
                            .font(.system(size: 15, weight: .black, design: .rounded))
                            .tracking(0.8)

                    }
                    .foregroundStyle(selectedPatchMode == mode ? .white : AppTheme.silver)
                    .frame(maxWidth: .infinity)
                    .frame(height: 46)
                    .background(
                        selectedPatchMode == mode
                            ? AppTheme.accent.opacity(0.22)
                            : Color.white.opacity(0.025),
                        in: RoundedRectangle(cornerRadius: 15, style: .continuous)
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 15, style: .continuous)
                            .stroke(
                                selectedPatchMode == mode ? AppTheme.accent : Color.white.opacity(0.08),
                                lineWidth: selectedPatchMode == mode ? 1.4 : 1
                            )
                    )
                }
                .buttonStyle(.plain)
            }
        }
        .padding(4)
        .background(
            Color.white.opacity(0.055),
            in: RoundedRectangle(cornerRadius: 19, style: .continuous)
        )
        .padding(.horizontal, 16)
        .padding(.top, 8)
    }

    private var patchSectionHeader: some View {
        HStack(alignment: .lastTextBaseline) {
            Label("PATCH OPTIONS", systemImage: "bolt.fill")
                .font(.system(size: 18, weight: .black, design: .rounded))
                .tracking(1.1)
                .foregroundStyle(AppTheme.accent)

            Spacer()

            Text("SELECT TO ACTIVATE")
                .font(.system(size: 9, weight: .bold, design: .rounded))
                .tracking(0.9)
                .foregroundStyle(AppTheme.silver)
        }
        .padding(.horizontal, 4)
    }

    @ViewBuilder
    private func patchCard(_ item: PatchLibraryItem) -> some View {
        let isActive = activeIDs.contains(item.id)
        let tint = cardTint(for: item)
        let isDisabled = false

        Button {

            if item.isLocked {
                store.requestUnlock(for: item)
            } else if isActive {
                restore(item)
            } else {
                apply(item)
            }
        } label: {
            VStack(alignment: .leading, spacing: 10) {
                HStack(alignment: .top) {
                    Image(systemName: isActive ? "bolt.fill" : "bolt")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundStyle(tint)

                    Spacer(minLength: 8)

                    // Green = active, red = inactive.
                    Circle()
                        .fill(isActive ? Color.green : Color.red)
                        .frame(width: 10, height: 10)
                        .overlay(
                            Circle()
                                .stroke(.white.opacity(0.22), lineWidth: 1)
                        )
                        .shadow(color: (isActive ? Color.green : Color.red).opacity(0.85), radius: 6)
                }

                Spacer(minLength: 2)

                Text(displayName(for: item))
                    .font(.system(size: 18, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .lineLimit(2)
                    .minimumScaleFactor(0.82)

                Text(gameLabel(for: item))
                    .font(.system(size: 12, weight: .bold, design: .rounded))
                    .tracking(0.8)
                    .foregroundStyle(tint)
                    .lineLimit(1)

                HStack(spacing: 7) {
                    Circle()
                        .fill(isDisabled ? AppTheme.silver : (isActive ? Color.green : Color.red))
                        .frame(width: 8, height: 8)

                    Text(isDisabled ? "DISABLED • NOT AVAILABLE" : (isActive ? "ACTIVE • TAP TO DISABLE" : "INACTIVE • TAP TO ACTIVATE"))
                        .font(.system(size: 10, weight: .bold, design: .rounded))
                        .tracking(0.65)
                        .foregroundStyle(isDisabled ? AppTheme.silver : (isActive ? Color.green : Color.red))
                        .lineLimit(1)
                        .minimumScaleFactor(0.75)
                }
            }
            .frame(maxWidth: .infinity, minHeight: 158, alignment: .topLeading)
            .padding(14)
            .background(
                LinearGradient(
                    colors: [
                        Color.white.opacity(0.045),
                        Color.black.opacity(0.2)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                in: RoundedRectangle(cornerRadius: 22, style: .continuous)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .stroke(
                        isActive ? Color.green : Color.red,
                        lineWidth: isActive ? 2.0 : 1.15
                    )
            )
            .shadow(
                color: isActive ? AppTheme.accent.opacity(0.22) : .clear,
                radius: 12
            )
        }
        .buttonStyle(.plain)
        .disabled(isDisabled || applyingID != nil || store.isBusy)
        .opacity(isDisabled ? 0.42 : (applyingID != nil && applyingID != item.id ? 0.55 : 1))
        .accessibilityLabel("\(displayName(for: item)), \(isDisabled ? "disabled" : (isActive ? "active" : "inactive"))")
    }

    private func patchCategory(for item: PatchLibraryItem) -> PatchCategory? {
        let name = displayName(for: item).uppercased()

        // Explicitly keep the requested new packages in their intended categories.
        if name.contains("TOP HEAD") ||
            name.contains("DRAG - ANTENA") ||
            name.contains("BODY HS 90") ||
            name.contains("AIMBOT") ||
            name.contains("BODY FFTH") ||
            name.contains("FFTH AIM BODY") ||
            name.contains("FFM AIM BODY") {
            return .aimbot
        }

        if name.contains("HOLO") || name.contains("HOLOGRAMA") || name.contains("AVATAR") {
            return .holograms
        }
        if name.contains("TEXTURA") || name.contains("TEXTURE") {
            return .textures
        }
        // Do not expose an OTHER section. Unclassified packages are hidden.
        return nil
    }

    private func patchSortKey(_ item: PatchLibraryItem) -> String {
        let name = displayName(for: item).uppercased()
        return name
    }

    private func patchMode(for item: PatchLibraryItem) -> PatchMode {
        let raw = item.packageURL.deletingPathExtension().lastPathComponent
        let upper = raw.uppercased()
        if upper.contains("FFMX") || upper.contains("FREE FIRE MAX") || upper.contains("FFM AIM BODY") {
            return .ffmx
        }
        return .ffth
    }

    private func displayName(for item: PatchLibraryItem) -> String {
        let raw = item.packageURL.deletingPathExtension().lastPathComponent
        let normalized = raw
            .replacingOccurrences(of: " FFTH", with: "")
            .replacingOccurrences(of: " FFMX", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        return normalized
    }

    private func gameLabel(for item: PatchLibraryItem) -> String {
        let name = displayName(for: item).uppercased()
        if name.contains("MAX") { return "FF MAX" }
        return "FF NORMAL"
    }

    private func cardTint(for item: PatchLibraryItem) -> Color {
        let name = displayName(for: item).uppercased()
        if name.contains("PECHO") || name.contains("CHEST") { return Color(red: 1.0, green: 0.12, blue: 0.34) }
        if name.contains("AIM") { return Color(red: 1.0, green: 0.62, blue: 0.05) }
        if name.contains("HOLO") || name.contains("WEAPON") { return Color(red: 1.0, green: 0.78, blue: 0.08) }
        return AppTheme.accent
    }

    private func syncActiveState() {
        activeIDs = Set(store.items.compactMap { item in
            DevicePatchService.latestReceipt(projectID: item.id) == nil ? nil : item.id
        })
    }

    private func consumeExternalImport() {
        guard let request = draftCoordinator.importRequest else { return }
        draftCoordinator.clearImport()
        store.importPackage(from: request.source)
    }

    private func apply(_ item: PatchLibraryItem) {
        guard !item.isLocked, let baseProject = item.project, applyingID == nil else { return }

        applyingID = item.id
        Task.detached(priority: .userInitiated) {
            do {
                let project: PatchProject
                if item.summary.schemaVersion >= 2 {
                    project = try PatchProjectLibrary.synchronizeWorkspace(item: item)
                } else {
                    project = baseProject
                }
                _ = try DevicePatchService.apply(project: project)

                await MainActor.run {
                    store.reload()
                    activeIDs.insert(item.id)
                    applyingID = nil
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    applyingID = nil
                    store.alert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    applyingID = nil
                    store.alert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: "patch.error.apply"
                    )
                }
            }
        }
    }

    private func restoreAll() {
        guard applyingID == nil, !activeIDs.isEmpty else { return }
        applyingID = UUID()

        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.restoreAll()
                await MainActor.run {
                    activeIDs.removeAll()
                    applyingID = nil
                    store.reload()
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    applyingID = nil
                    store.alert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                    syncActiveState()
                }
            } catch {
                await MainActor.run {
                    applyingID = nil
                    store.alert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: "patch.error.restore"
                    )
                    syncActiveState()
                }
            }
        }
    }

    private func restore(_ item: PatchLibraryItem) {
        guard applyingID == nil, let receipt = DevicePatchService.latestReceipt(projectID: item.id) else {
            activeIDs.remove(item.id)
            return
        }

        applyingID = item.id
        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.restore(receipt: receipt)
                await MainActor.run {
                    activeIDs.remove(item.id)
                    applyingID = nil
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    applyingID = nil
                    store.alert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    applyingID = nil
                    store.alert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: "patch.error.apply"
                    )
                }
            }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: "shippingbox")
                .font(.system(size: AppTheme.emptyIconSize, weight: .light))
                .foregroundStyle(AppTheme.accent)
            Text(language.text("patch.empty_title"))
                .font(.headline)
            Text(language.text("patch.empty_message"))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 64)
    }

    private var modeEmptyState: some View {
        VStack(spacing: 10) {
            Image(systemName: selectedPatchMode == .ffth ? "antenna.radiowaves.left.and.right" : "bolt.horizontal.fill")
                .font(.system(size: AppTheme.emptyIconSize, weight: .light))
                .foregroundStyle(AppTheme.accent)
            Text("No \(selectedPatchMode.rawValue) patches")
                .font(.headline)
            Text("No patches are available in this section.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 64)
    }
}

private struct PatchProjectRow: View {
    let item: PatchLibraryItem
    let language: AppLanguage

    var body: some View {
        HStack(spacing: 12) {
            AppRowIcon(systemName: item.isLocked ? "lock.doc.fill" : "shippingbox.fill")
            VStack(alignment: .leading, spacing: 3) {
                Text(item.project?.name ?? language.text("patch.locked_project"))
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.primary)
                Text(item.isLocked
                     ? language.text("patch.tap_to_unlock")
                     : language.text(
                        item.summary.schemaVersion >= 2 ? "patch.workspace_items_count" : "patch.rules_count",
                        Int64((item.project?.rules.count ?? 0) + (item.project?.directories.count ?? 0))
                     ))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            if item.summary.isPasswordProtected {
                Image(systemName: "key.fill")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .accessibilityLabel(language.text("patch.password_protected"))
            }
        }
        .padding(.vertical, 4)
    }
}

private struct PatchUnlockView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: PatchProjectStore
    @State private var password = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField(language.text("patch.password"), text: $password)
                        .textContentType(.password)
                        .submitLabel(.done)
                        .onSubmit(unlock)
                        .onChange(of: password) { _ in
                            store.clearUnlockError()
                        }
                    if let errorKey = store.unlockErrorKey {
                        Text(language.text(errorKey))
                            .font(.footnote)
                            .foregroundStyle(.red)
                    }
                } footer: {
                    Text(language.text("patch.password_once_message"))
                }
            }
            .navigationTitle(language.text("patch.unlock"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(language.text("common.cancel")) { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(language.text("patch.unlock"), action: unlock)
                        .disabled(password.isEmpty || store.isBusy)
                }
            }
        }
    }

    private func unlock() {
        guard !password.isEmpty else { return }
        store.unlock(password: password)
    }
}

private struct PatchProjectDetailView: View {
    @Environment(\.appLanguage) private var language
    @ObservedObject var store: PatchProjectStore
    let projectID: UUID
    @State private var showEditor = false
    @State private var editingRule: PatchRule?
    @State private var showApplyConfirmation = false
    @State private var showRestoreConfirmation = false
    @State private var isWorking = false
    @State private var actionAlert: PatchStoreAlert?
    @State private var shareRequest: PatchShareRequest?

    private var item: PatchLibraryItem? {
        store.items.first(where: { $0.id == projectID })
    }

    private var receipt: PatchTransactionReceipt? {
        DevicePatchService.latestReceipt(projectID: projectID)
    }

    private var isWorkspaceProject: Bool {
        (item?.summary.schemaVersion ?? 1) >= 2
    }

    var body: some View {
        List {
            if let item, let project = item.project {
                if isWorkspaceProject {
                    Section {
                        ForEach(project.allBundleIdentifiers, id: \.self) { bundleID in
                            Label {
                                Text(bundleID)
                                    .font(.subheadline.monospaced())
                            } icon: {
                                Image(systemName: "app.dashed")
                                    .foregroundStyle(AppTheme.accent)
                            }
                        }
                        LabeledContent(language.text("patch.files")) {
                            Text("\(project.rules.count)")
                        }
                        LabeledContent(language.text("patch.folders")) {
                            Text("\(project.directories.count)")
                        }
                        if let workspaceURL = item.workspaceURL {
                            NavigationLink {
                                FileBrowserView(
                                    containerPath: workspaceURL.path,
                                    title: project.name,
                                    bundleID: nil
                                )
                            } label: {
                                Label(
                                    language.text("patch.open_workspace"),
                                    systemImage: "folder"
                                )
                            }
                        }
                    } header: {
                        Text(language.text("patch.workspace"))
                    } footer: {
                        Text(language.text("patch.workspace_detail_footer"))
                    }
                } else {
                    Section {
                        ForEach(project.rules) { rule in
                            Button {
                                editingRule = rule
                            } label: {
                                HStack(spacing: 10) {
                                    ruleSummary(rule)
                                    Spacer(minLength: 8)
                                    Image(systemName: "chevron.right")
                                        .font(.caption.weight(.semibold))
                                        .foregroundStyle(.tertiary)
                                }
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .accessibilityHint(language.text("patch.edit_rule_hint"))
                        }
                    } header: {
                        Text(language.text("patch.rules"))
                    } footer: {
                        Text(language.text("patch.legacy_footer"))
                    }
                }

                Section(language.text("patch.password")) {
                    HStack(spacing: 12) {
                        Image(systemName: item.summary.isPasswordProtected ? "lock.fill" : "lock.open")
                            .foregroundStyle(AppTheme.accent)
                            .frame(width: 24)
                        Text(language.text(item.summary.isPasswordProtected
                            ? "patch.password_locked"
                            : "patch.no_password"))
                            .font(.subheadline)
                    }
                }

                Section {
                    Button {
                        showApplyConfirmation = true
                    } label: {
                        actionLabel("patch.apply", systemImage: "checkmark.shield.fill")
                    }
                    .disabled(isWorking)

                    if receipt != nil {
                        Button(role: .destructive) {
                            showRestoreConfirmation = true
                        } label: {
                            actionLabel("patch.restore", systemImage: "arrow.uturn.backward.circle")
                        }
                        .disabled(isWorking)
                    }

                    Button(action: prepareExport) {
                        actionLabel("patch.export", systemImage: "square.and.arrow.up")
                    }
                    .disabled(isWorking)
                } footer: {
                    Text(language.text("patch.apply_footer"))
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle(item?.project?.name ?? language.text("patch.title"))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                if isWorking {
                    ProgressView()
                } else if !isWorkspaceProject {
                    Button(language.text("patch.edit")) { showEditor = true }
                        .disabled(item?.project == nil)
                }
            }
        }
        .sheet(isPresented: $showEditor) {
            if let item, let project = item.project {
                PatchProjectEditorView(
                    existingProject: project,
                    passwordIsProtected: item.summary.isPasswordProtected
                ) { updatedProject, _ in
                    store.update(project: updatedProject)
                }
            }
        }
        .sheet(item: $editingRule) { rule in
            PatchRuleEditorView(rule: rule) { updatedRule in
                updateRule(updatedRule)
            }
        }
        .confirmationDialog(
            language.text("patch.apply_confirm_title"),
            isPresented: $showApplyConfirmation,
            titleVisibility: .visible
        ) {
            Button(language.text("patch.apply")) { apply() }
            Button(language.text("common.cancel"), role: .cancel) {}
        } message: {
            Text(language.text("patch.apply_confirm_message"))
        }
        .confirmationDialog(
            language.text("patch.restore_confirm_title"),
            isPresented: $showRestoreConfirmation,
            titleVisibility: .visible
        ) {
            Button(language.text("patch.restore"), role: .destructive) { restore() }
            Button(language.text("common.cancel"), role: .cancel) {}
        }
        .alert(item: $actionAlert) { alert in
            Alert(
                title: Text(language.text(alert.titleKey)),
                message: Text(alert.message(language: language)),
                dismissButton: .default(Text(language.text("common.ok")))
            )
        }
        .sheet(item: $shareRequest) { request in
            PatchActivityView(items: [request.url])
                .ignoresSafeArea()
        }
    }

    private func actionLabel(_ key: String, systemImage: String) -> some View {
        Label(language.text(key), systemImage: systemImage)
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func ruleSummary(_ rule: PatchRule) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(rule.bundleID)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.primary)
            Text(rule.relativePath)
                .font(.caption.monospaced())
                .foregroundStyle(.secondary)
                .lineLimit(2)
            Label(rule.replacementFilename, systemImage: "arrow.triangle.2.circlepath")
                .font(.caption)
                .foregroundStyle(AppTheme.accent)
        }
        .padding(.vertical, 3)
    }

    private func updateRule(_ updatedRule: PatchRule) {
        guard var project = item?.project,
              let index = project.rules.firstIndex(where: { $0.id == updatedRule.id }) else {
            return
        }
        project.rules[index] = updatedRule
        project.updatedAt = Date()
        do {
            try PatchPackageCodec.validate(project)
            store.update(project: project)
        } catch let error as PatchPackageError {
            actionAlert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: error.localizationKey,
                messageArgument: error.localizationArgument
            )
        } catch {
            actionAlert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: "patch.error.invalid_project"
            )
        }
    }

    private func apply() {
        guard let item, let baseProject = item.project else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                let project = item.summary.schemaVersion >= 2
                    ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                    : baseProject
                _ = try DevicePatchService.apply(project: project)
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.applied_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.apply")
                }
            }
        }
    }

    private func prepareExport() {
        guard let item else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                if item.summary.schemaVersion >= 2 {
                    _ = try PatchProjectLibrary.synchronizeWorkspace(item: item)
                }
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    shareRequest = PatchShareRequest(url: item.packageURL)
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: "patch.error.invalid_project"
                    )
                }
            }
        }
    }

    private func restore() {
        guard let receipt else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.restore(receipt: receipt)
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.restored_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.restore")
                }
            }
        }
    }
}

private struct PatchShareRequest: Identifiable {
    let id = UUID()
    let url: URL
}

private struct PatchActivityView: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(
        _ uiViewController: UIActivityViewController,
        context: Context
    ) {}
}
