# Patch UI changes

- Main navigation now shows Home, Patches, and Cleaner only; Files and Wallpapers are removed from the main navigation.
- Patches is split into FFTH and FFMX tabs.
- Patches are displayed as dark rounded cards in a two-column grid.
- Each card has a status light: green when active, red when inactive.
- Tapping an inactive patch applies it directly; tapping an active patch restores that patch without the old detail/confirmation screen.
- Added a Restore Originals button in the Patches toolbar that restores all active patch transactions.
- The supplied `.3105` packages from `ARCHIVOS 3105.zip` are bundled in `SeedPatches` and installed into the local patch library automatically when missing.
- The UI displays `AIMBOT BODY` for the package previously named `AIMBOT PECHO`.
