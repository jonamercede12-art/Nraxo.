# Custom patch UI changes

- Removed the Files and Wallpaper tabs from the main navigation.
- Redesigned the Patches screen around dark rounded cards and a patch-focused layout.
- Tapping an unlocked patch card applies the patch directly; the old detail/confirmation step is bypassed.
- Bundled all supplied `.3105` packages from `ARCHIVOS 3105.zip` under `ThreeOneOSFive/SeedPatches`.
- Bundled `.3105` packages are installed into the local patch library automatically on first launch when missing.
