import Foundation

struct PatchLibraryItem: Identifiable {
    let summary: PatchPackageSummary
    var project: PatchProject?
    var contentKey: Data?
    var packageURL: URL

    var id: UUID { summary.packageID }
    var isLocked: Bool { project == nil }
    var workspaceURL: URL? {
        PatchWorkspaceService.workspaceURL(projectID: id)
    }
}

struct PatchPasswordRequest: Identifiable {
    let summary: PatchPackageSummary
    var id: UUID { summary.packageID }
}

enum PatchProjectLibrary {
    private static let bundledRefreshNames: Set<String> = [
        "BODY HS 90- FFTH.3105",
        "DRAG - ANTENA FFTH.3105",
        "TOP HEAD FFTH.3105",
        "HOLOGRAM WEAPONS MULTICOLORED FFTH.3105",
        "HOLOGRAM WEAPONS MULTICOLORED FFMX.3105",
        "Esp FFTH.3105"
    ]

    private static let removedLegacyHologramNames: Set<String> = [
        "HOLO FFTH.3105",
        "HOLO AVATAR GREEN.3105",
        "HOLOGRAMA WEAPONS BLUE FFMX.3105",
        "HOLOGRAMA GLOO FFTH.3105"
    ]

    /// Bundled holograms are kept in their requested source/resource folders.
    /// The same folders are mirrored inside Application Support/PatchProjects.
    private static let routedBundledPackages: [(name: String, subdirectory: String)] = [
        (
            "HOLOGRAM WEAPONS MULTICOLORED FFMX.3105",
            "SeedPatches/holo/hologramas de ffmx"
        ),
        (
            "HOLOGRAM WEAPONS MULTICOLORED FFTH.3105",
            "SeedPatches/holo/hologrmas"
        )
    ]

    /// Installs the bundled patch package into the local PatchProjects library
    /// the first time the app is launched (or after the local copy is removed).
    /// The original package is shipped as a resource, not as a ZIP.
    static func installBundledDefaults(
        bundle: Bundle = .main,
        fileManager: FileManager = .default
    ) {
        do {
            let root = try packageRootURL(fileManager: fileManager)

            // Remove obsolete resources from previous app versions.
            let obsoleteNames = removedLegacyHologramNames.union(["OPTIONALAVATARRES.3105"])
            if let enumerator = fileManager.enumerator(
                at: root,
                includingPropertiesForKeys: [.isRegularFileKey, .isDirectoryKey],
                options: [.skipsHiddenFiles]
            ) {
                for case let url as URL in enumerator {
                    if obsoleteNames.contains(url.lastPathComponent.uppercased()) ||
                        url.lastPathComponent.uppercased().contains("OPTIONALAVATAR") {
                        try? fileManager.removeItem(at: url)
                    }
                }
            }

            // Xcode folder references are copied into the app bundle without
            // necessarily preserving the SeedPatches parent folder. Therefore
            // search the entire bundle recursively instead of assuming that
            // Bundle.main/SeedPatches exists.
            guard let bundleRoot = bundle.resourceURL,
                  let enumerator = fileManager.enumerator(
                      at: bundleRoot,
                      includingPropertiesForKeys: [.isRegularFileKey, .isDirectoryKey],
                      options: [.skipsHiddenFiles]
                  ) else {
                log("patch: app bundle resource directory is missing")
                return
            }

            for case let sourceURL as URL in enumerator {
                guard sourceURL.pathExtension.lowercased() == "3105" else { continue }

                let name = sourceURL.lastPathComponent
                let upperName = name.uppercased()
                guard !upperName.contains("MAGIC BULLET"),
                      !upperName.contains("OPTIONALAVATAR"),
                      !removedLegacyHologramNames.contains(upperName) else {
                    continue
                }

                // Keep the two requested holograms in their logical library
                // folders even though Xcode may flatten the bundle resource.
                let destination: URL
                switch upperName {
                case "HOLOGRAM WEAPONS MULTICOLORED FFMX.3105":
                    destination = root
                        .appendingPathComponent("holo", isDirectory: true)
                        .appendingPathComponent("hologramas de ffmx", isDirectory: true)
                        .appendingPathComponent(name)
                case "HOLOGRAM WEAPONS MULTICOLORED FFTH.3105", "ESP FFTH.3105":
                    destination = root
                        .appendingPathComponent("holo", isDirectory: true)
                        .appendingPathComponent("hologrmas", isDirectory: true)
                        .appendingPathComponent(name)
                default:
                    destination = root.appendingPathComponent(name)
                }
                let relativePath = destination.path.replacingOccurrences(
                    of: root.path + "/", with: ""
                )
                let destinationDirectory = destination.deletingLastPathComponent()
                try fileManager.createDirectory(
                    at: destinationDirectory,
                    withIntermediateDirectories: true
                )

                if fileManager.fileExists(atPath: destination.path),
                   bundledRefreshNames.contains(upperName) {
                    try? fileManager.removeItem(at: destination)
                }

                if fileManager.fileExists(atPath: destination.path) { continue }

                do {
                    let data = try Data(contentsOf: sourceURL, options: .mappedIfSafe)
                    _ = try PatchPackageCodec.inspect(data)
                    try fileManager.copyItem(at: sourceURL, to: destination)
                    log("patch: installed bundled package at \(relativePath)")
                } catch {
                    log("patch: skipped invalid bundled package \(relativePath): \(error)")
                }
            }
        } catch {
            log("patch: failed to install bundled patch catalog: \(error)")
        }
    }

    static func packageRootURL(fileManager: FileManager = .default) throws -> URL {
        let base = try fileManager.url(
            for: .applicationSupportDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )
        let root = base.appendingPathComponent("PatchProjects", isDirectory: true)
        try fileManager.createDirectory(at: root, withIntermediateDirectories: true)
        return root
    }

    static func backupRootURL(fileManager: FileManager = .default) throws -> URL {
        let root = try packageRootURL(fileManager: fileManager)
            .appendingPathComponent("Backups", isDirectory: true)
        try fileManager.createDirectory(at: root, withIntermediateDirectories: true)
        return root
    }

    static func load(fileManager: FileManager = .default) -> [PatchLibraryItem] {
        guard let root = try? packageRootURL(fileManager: fileManager),
              let enumerator = fileManager.enumerator(
                at: root,
                includingPropertiesForKeys: [.contentModificationDateKey, .fileSizeKey],
                options: [.skipsHiddenFiles],
                errorHandler: { url, error in
                    log("patch: failed to enumerate \(url.path): \(error)")
                    return true
                }
              ) else { return [] }

        var byID: [UUID: PatchLibraryItem] = [:]

        for case let url as URL in enumerator where
            url.pathExtension.lowercased() == "3105" &&
            !url.lastPathComponent.uppercased().contains("MAGIC BULLET") &&
            !url.lastPathComponent.uppercased().contains("OPTIONALAVATAR") &&
            !removedLegacyHologramNames.contains(url.lastPathComponent.uppercased()) {
            do {
                let data = try readPackage(at: url)
                let summary = try PatchPackageCodec.inspect(data)
                let decoded: DecodedPatchPackage?
                if let contentKey = try PatchKeyStore.load(for: summary) {
                    decoded = try PatchPackageCodec.decode(data, contentKey: contentKey)
                } else if summary.isPasswordProtected {
                    decoded = nil
                } else {
                    decoded = try PatchPackageCodec.decode(data, password: nil)
                }
                let item = PatchLibraryItem(
                    summary: summary,
                    project: decoded?.project,
                    contentKey: decoded?.contentKey,
                    packageURL: url
                )
                if summary.schemaVersion >= 2, let project = decoded?.project {
                    do {
                        _ = try PatchWorkspaceService.ensureWorkspace(for: project)
                    } catch {
                        log("patch: workspace unavailable for \(project.id.uuidString)")
                    }
                }
                byID[summary.packageID] = item
            } catch {
                log("patch: skipped invalid local package \(url.lastPathComponent)")
            }
        }
        return byID.values.sorted {
            ($0.project?.updatedAt ?? .distantPast) > ($1.project?.updatedAt ?? .distantPast)
        }
    }

    static func readPackage(at url: URL) throws -> Data {
        let values = try url.resourceValues(forKeys: [.isDirectoryKey, .isRegularFileKey, .isSymbolicLinkKey])
        guard values.isDirectory != true,
              values.isSymbolicLink != true,
              values.isRegularFile == true else {
            throw PatchPackageError.invalidProject
        }
        return try Data(contentsOf: url, options: .mappedIfSafe)
    }

    static func save(
        data: Data,
        projectName: String,
        existingURL: URL? = nil,
        fileManager: FileManager = .default
    ) throws -> URL {
        let destination: URL
        if let existingURL {
            destination = existingURL
        } else {
            let root = try packageRootURL(fileManager: fileManager)
            let baseName = sanitizedFilename(projectName)
            var candidate = root.appendingPathComponent(baseName).appendingPathExtension("3105")
            var suffix = 2
            while fileManager.fileExists(atPath: candidate.path) {
                candidate = root.appendingPathComponent("\(baseName)-\(suffix)").appendingPathExtension("3105")
                suffix += 1
            }
            destination = candidate
        }
        try data.write(to: destination, options: [.atomic, .completeFileProtection])
        return destination
    }

    static func installImportedPackage(
        data: Data,
        decoded: DecodedPatchPackage,
        summary: PatchPackageSummary,
        existingURL: URL?,
        fileManager: FileManager = .default
    ) throws {
        let previousData = try existingURL.map { try readPackage(at: $0) }
        var savedURL: URL?
        do {
            savedURL = try save(
                data: data,
                projectName: decoded.project.name,
                existingURL: existingURL,
                fileManager: fileManager
            )
            if summary.schemaVersion >= 2 {
                _ = try PatchWorkspaceService.replaceWorkspace(
                    with: decoded.project,
                    fileManager: fileManager
                )
            } else {
                try? PatchWorkspaceService.deleteWorkspace(
                    projectID: decoded.project.id,
                    fileManager: fileManager
                )
            }
        } catch {
            if let previousData, let existingURL {
                try? previousData.write(
                    to: existingURL,
                    options: [.atomic, .completeFileProtection]
                )
            } else if let savedURL, fileManager.fileExists(atPath: savedURL.path) {
                try? fileManager.removeItem(at: savedURL)
            }
            throw error
        }
    }

    static func delete(_ item: PatchLibraryItem, fileManager: FileManager = .default) throws {
        if fileManager.fileExists(atPath: item.packageURL.path) {
            try fileManager.removeItem(at: item.packageURL)
        }
        try? PatchWorkspaceService.deleteWorkspace(projectID: item.id, fileManager: fileManager)
        try? PatchKeyStore.delete(for: item.summary)
    }

    static func synchronizeWorkspace(
        item: PatchLibraryItem,
        fileManager: FileManager = .default
    ) throws -> PatchProject {
        guard item.summary.schemaVersion >= 2,
              let baseProject = item.project,
              let contentKey = item.contentKey else {
            throw PatchPackageError.invalidProject
        }
        let workspace = try PatchWorkspaceService.ensureWorkspace(
            for: baseProject,
            fileManager: fileManager
        )
        let project = try PatchWorkspaceService.snapshot(
            baseProject: baseProject,
            workspaceURL: workspace,
            fileManager: fileManager
        )
        let original = try readPackage(at: item.packageURL)
        let updated = try PatchPackageCodec.update(
            original,
            project: project,
            contentKey: contentKey,
            schemaVersion: PatchPackageCodec.latestSchemaVersion
        )
        _ = try save(
            data: updated,
            projectName: project.name,
            existingURL: item.packageURL,
            fileManager: fileManager
        )
        return project
    }

    private static func sanitizedFilename(_ rawName: String) -> String {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-_ "))
        let scalars = rawName.unicodeScalars.map { allowed.contains($0) ? Character(String($0)) : "-" }
        let result = String(scalars)
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .prefix(80)
        return result.isEmpty ? "Patch" : String(result)
    }
}
