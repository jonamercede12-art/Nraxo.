-- Allows a device to reuse a new license after its previous license expires.
-- Apply this migration to the Nraxo Supabase project.
-- The app already calls public.activate_license(p_license_key, p_device_id).

create or replace function public.activate_license(p_license_key text, p_device_id text)
returns table(valid boolean, status text, message text, license_id bigint, expires_at timestamptz, activated_at timestamptz, linked_at timestamptz)
language plpgsql
security definer
set search_path to 'public', 'pg_temp'
as $function$
declare
  k text := upper(btrim(coalesce(p_license_key,'')));
  d text := upper(btrim(coalesce(p_device_id,'')));
  l public.license_keys%rowtype;
  other_id bigint;
begin
  if k='' or length(k)>256 or d='' or length(d)>128 then
    return query select false,'invalid_request','Llave o Device ID inválido',null::bigint,null::timestamptz,null::timestamptz,null::timestamptz;
    return;
  end if;

  perform pg_advisory_xact_lock(hashtextextended(d,0));

  -- Release expired bindings for this device before checking for another
  -- active license. This makes expired keys no longer occupy the device.
  update public.license_keys
     set device_id = null,
         linked_at = null
   where upper(btrim(coalesce(lk.device_id,''))) = d
     and lk.expires_at is not null
     and lk.expires_at <= now();

  select * into l
    from public.license_keys lk
   where upper(btrim(lk.key))=k
   for update;

  if not found then
    return query select false,'invalid_key','La llave no es válida',null::bigint,null::timestamptz,null::timestamptz,null::timestamptz;
    return;
  end if;

  if not l.active then
    return query select false,'revoked','La licencia está desactivada o revocada',l.id,l.expires_at,l.activated_at,l.linked_at;
    return;
  end if;

  if l.expires_at is not null and l.expires_at<=now() then
    update public.license_keys
       set device_id = null,
           linked_at = null
     where id = l.id;
    l.device_id := null;
    l.linked_at := null;
    return query select false,'expired','La licencia está vencida',l.id,l.expires_at,l.activated_at,l.linked_at;
    return;
  end if;

  if l.device_id is not null and upper(btrim(l.device_id))<>d then
    return query select false,'bound_elsewhere','La licencia ya está vinculada a otro dispositivo',l.id,l.expires_at,l.activated_at,l.linked_at;
    return;
  end if;

  select lk.id into other_id
    from public.license_keys lk
   where upper(btrim(lk.device_id))=d
     and lk.id<>l.id
     and (lk.expires_at is null or lk.expires_at>now())
   limit 1;

  if found then
    return query select false,'device_already_bound','Este dispositivo ya tiene una licencia vinculada',other_id,null::timestamptz,null::timestamptz,null::timestamptz;
    return;
  end if;

  update public.license_keys lk
     set device_id=d,
         activated_at=coalesce(lk.activated_at,now()),
         linked_at=coalesce(lk.linked_at,now()),
         last_used_at=now()
   where lk.id=l.id
   returning lk.* into l;

  return query select true,'active','Licencia activada y vinculada a este dispositivo',l.id,l.expires_at,l.activated_at,l.linked_at;
end;
$function$;
